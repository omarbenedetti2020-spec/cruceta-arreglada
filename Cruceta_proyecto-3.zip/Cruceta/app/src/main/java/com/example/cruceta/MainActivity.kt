package com.example.cruceta

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.text.Editable
import android.text.TextWatcher
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.OutputStream
import java.util.UUID
import java.util.concurrent.Executors

@SuppressLint("MissingPermission", "ClickableViewAccessibility")
class MainActivity : Activity() {

    private val sppUuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private val sendIntervalMs = 50L // frecuencia de envío mientras se mantiene presionado

    private var socket: BluetoothSocket? = null
    private var output: OutputStream? = null
    private val io = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var status: TextView

    private var currentChar: Char? = null
    private val repeater = object : Runnable {
        override fun run() {
            currentChar?.let { send(it) }
            if (currentChar != null) ui.postDelayed(this, sendIntervalMs)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = cBg
        window.navigationBarColor = cBg
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode =
                    android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        goFullscreen()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(cBg, Color.parseColor("#151A26"))
            )
            setPadding(dp(36), dp(12), dp(36), dp(16))
        }

        // ---- Barra superior: estado + botón conectar ----
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        statusDot = View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(cOff) }
        }
        status = TextView(this).apply {
            text = "Desconectado"
            setTextColor(Color.WHITE)
            textSize = 14f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    val t = s?.toString() ?: ""
                    val color = when {
                        t.startsWith("Conectado") -> cOk
                        t.startsWith("Conectando") -> cWarn
                        else -> cOff
                    }
                    (statusDot.background as GradientDrawable).setColor(color)
                }
            })
        }
        val pill = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(10), dp(18), dp(10))
            background = GradientDrawable().apply {
                cornerRadius = dp(24).toFloat()
                setColor(cSurface)
                setStroke(dp(1), Color.parseColor("#2A3142"))
            }
            addView(statusDot, LinearLayout.LayoutParams(dp(10), dp(10)).apply { rightMargin = dp(10) })
            addView(status)
        }
        val connectBtn = Button(this).apply {
            text = "Conectar"
            isAllCaps = false
            textSize = 14f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            stateListAnimator = null
            minHeight = 0; minimumHeight = 0
            setPadding(dp(22), dp(10), dp(22), dp(10))
            background = padBackground(cBlue, filled = true, radius = 24)
            setOnClickListener { chooseDevice() }
        }
        top.addView(pill, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(connectBtn, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(12) })
        root.addView(top, LinearLayout.LayoutParams(-1, -2))

        // ---- Cruceta ----
        val grid = GridLayout(this).apply {
            rowCount = 3
            columnCount = 3
        }
        fun pad(label: String, ch: Char, row: Int, col: Int) {
            val accent = if (ch == 'Z') cRed else cBlue
            val b = Button(this).apply {
                text = label
                textSize = 30f
                isAllCaps = false
                includeFontPadding = false
                stateListAnimator = null
                setTextColor(ColorStateList(
                    arrayOf(intArrayOf(android.R.attr.state_pressed), intArrayOf()),
                    intArrayOf(Color.WHITE, accent)
                ))
                background = padBackground(accent, filled = false, radius = 28)
                setOnTouchListener { v, e ->
                    when (e.actionMasked) {
                        MotionEvent.ACTION_DOWN -> {
                            v.isPressed = true
                            v.animate().scaleX(0.94f).scaleY(0.94f).setDuration(70).start()
                            v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                            startSending(ch)
                        }
                        MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                            v.isPressed = false
                            v.animate().scaleX(1f).scaleY(1f).setDuration(110).start()
                            stopSending()
                        }
                    }
                    true
                }
            }
            val lp = GridLayout.LayoutParams(GridLayout.spec(row, 1f), GridLayout.spec(col, 1f)).apply {
                width = 0; height = 0; setMargins(dp(7), dp(7), dp(7), dp(7))
            }
            grid.addView(b, lp)
        }
        pad("▲", 'F', 0, 1)
        pad("◀", 'L', 1, 0)
        pad("●", 'Z', 1, 1)
        pad("▶", 'R', 1, 2)
        pad("▼", 'B', 2, 1)
        root.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(8) })

        setContentView(root)
        requestBtPermission()
    }


    // ---------- Estilo ----------
    private val cBg = Color.parseColor("#0C0F16")
    private val cSurface = Color.parseColor("#1A2030")
    private val cBlue = Color.parseColor("#4C8DFF")
    private val cRed = Color.parseColor("#FF4D5E")
    private val cOk = Color.parseColor("#34D399")
    private val cWarn = Color.parseColor("#FBBF24")
    private val cOff = Color.parseColor("#6B7280")
    private lateinit var statusDot: View

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    /** Fondo con estados: normal = superficie oscura con borde suave; presionado = relleno de color + borde brillante. */
    private fun padBackground(accent: Int, filled: Boolean, radius: Int): StateListDrawable {
        fun shape(fill: Int, stroke: Int, strokeW: Int) = GradientDrawable().apply {
            cornerRadius = dp(radius).toFloat()
            setColor(fill)
            setStroke(dp(strokeW), stroke)
        }
        val a = Color.argb(255, Color.red(accent), Color.green(accent), Color.blue(accent))
        val dim = Color.argb(90, Color.red(accent), Color.green(accent), Color.blue(accent))
        val light = Color.argb(255,
            minOf(255, Color.red(accent) + 40), minOf(255, Color.green(accent) + 40), minOf(255, Color.blue(accent) + 40))
        val normal = if (filled) shape(a, a, 1) else shape(cSurface, dim, 2)
        val pressed = shape(if (filled) light else a, light, 3)
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), pressed)
            addState(intArrayOf(), normal)
        }
    }

    @Suppress("DEPRECATION")
    private fun goFullscreen() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            )
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) goFullscreen()
    }

    private fun requestBtPermission() {
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 1)
    }

    private fun adapter(): BluetoothAdapter? =
        (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter

    private fun chooseDevice() {
        val ad = adapter()
        if (ad == null || !ad.isEnabled) {
            Toast.makeText(this, "Activa el Bluetooth", Toast.LENGTH_SHORT).show()
            return
        }
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) { requestBtPermission(); return }

        val devices: List<BluetoothDevice> = ad.bondedDevices.toList()
        if (devices.isEmpty()) {
            Toast.makeText(this, "Vincula primero el dispositivo en Ajustes > Bluetooth", Toast.LENGTH_LONG).show()
            return
        }
        val names = devices.map { "${it.name ?: "?"}\n${it.address}" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Elige dispositivo")
            .setItems(names) { _, i -> connect(devices[i]) }
            .show()
    }

    private fun connect(device: BluetoothDevice) {
        status.text = "Conectando a ${try { device.name } catch (_: Throwable) { device.address }}..."
        io.execute {
            close()
            // cancelDiscovery pide permiso BLUETOOTH_SCAN en Android 12+; no es necesario para conectar
            try { adapter()?.cancelDiscovery() } catch (_: Throwable) {}
            var lastError: Throwable? = null

            // Intento 1: método estándar (SPP)
            // Intento 2: método alternativo (canal 1), necesario en varios celulares con HC-05
            for (attempt in 1..2) {
                try {
                    val s: BluetoothSocket = if (attempt == 1) {
                        device.createRfcommSocketToServiceRecord(sppUuid)
                    } else {
                        device.javaClass.getMethod("createRfcommSocket", Int::class.javaPrimitiveType)
                            .invoke(device, 1) as BluetoothSocket
                    }
                    s.connect()
                    socket = s
                    output = s.outputStream
                    ui.post { status.text = "Conectado: ${device.name}" }
                    return@execute
                } catch (e: Throwable) {
                    lastError = e
                    close()
                    try { Thread.sleep(400) } catch (_: InterruptedException) {}
                }
            }
            val msg = lastError?.message ?: lastError?.javaClass?.simpleName ?: "desconocido"
            ui.post { status.text = "Error al conectar ($msg)" }
        }
    }

    private fun startSending(c: Char) {
        currentChar = c
        ui.removeCallbacks(repeater)
        ui.post(repeater)
    }

    private fun stopSending() {
        currentChar = null
        ui.removeCallbacks(repeater)
    }

    private fun send(c: Char) {
        io.execute {
            try {
                output?.apply { write(c.code); flush() }
            } catch (e: Exception) {
                close()
                ui.post { status.text = "Conexión perdida" }
            }
        }
    }

    private fun close() {
        try { socket?.close() } catch (_: Exception) {}
        socket = null; output = null
    }

    override fun onDestroy() {
        stopSending()
        close()
        io.shutdown()
        super.onDestroy()
    }
}
