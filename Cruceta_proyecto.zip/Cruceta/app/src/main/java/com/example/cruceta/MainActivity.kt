package com.example.cruceta

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.OutputStream
import java.util.UUID
import java.util.concurrent.Executors

@SuppressLint("MissingPermission", "ClickableViewAccessibility")
class MainActivity : Activity() {

    private val sppUuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private val sendIntervalMs = 50L // frecuencia de envío mientras se mantiene presionado

    private var socket: BluetoothSocket? = null
    private var output: OutputStream? = null
    private val io = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var status: TextView
    private lateinit var connectBtn: Button

    // Botones apretados a la vez (en orden). Se envían por turnos mientras sigan apretados.
    private val held = ArrayList<Char>()
    private val padViews = HashMap<Char, View>()
    private var turn = 0
    private val repeater = object : Runnable {
        override fun run() {
            if (held.isEmpty()) return
            if (turn >= held.size) turn = 0
            send(held[turn])
            turn++
            ui.postDelayed(this, sendIntervalMs)
        }
    }

    // ---------- Estilo ----------
    private val cBg = Color.parseColor("#0C0F16")
    private val cSurface = Color.parseColor("#1A2030")
    private val cSurfaceTop = Color.parseColor("#252D42")
    private val cBlue = Color.parseColor("#4C8DFF")
    private val cRed = Color.parseColor("#FF4D5E")
    private val cGold = Color.parseColor("#FFB020")
    private val cOk = Color.parseColor("#34D399")
    private val cWarn = Color.parseColor("#FBBF24")
    private val cOff = Color.parseColor("#6B7280")
    private lateinit var statusDot: View


    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun withAlpha(c: Int, a: Int) = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))
    private fun lighten(c: Int, d: Int) = Color.rgb(
        minOf(255, Color.red(c) + d), minOf(255, Color.green(c) + d), minOf(255, Color.blue(c) + d)
    )

    /**
     * Fondo con estados.
     * Normal: superficie oscura con degradado y borde suave del color.
     * Presionado: relleno brillante del color con borde luminoso.
     */
    private fun padBackground(color: Int, filled: Boolean, radius: Int): StateListDrawable {
        fun shape(top: Int, bottom: Int, stroke: Int, strokeW: Int) = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, bottom)
        ).apply {
            cornerRadius = dp(radius).toFloat()
            setStroke(dp(strokeW), stroke)
        }
        val normal = if (filled) shape(lighten(color, 25), color, withAlpha(color, 255), 1)
        else shape(cSurfaceTop, cSurface, withAlpha(color, 110), 2)
        val pressed = shape(lighten(color, 70), color, lighten(color, 110), 3)
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), pressed)
            addState(intArrayOf(), normal)
        }
    }

    /** Eventos táctiles comunes: efecto visual + envío de la letra mientras se mantiene presionado. */
    private fun attachTouch(b: Button, ch: Char) {
        b.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.isPressed = true
                    v.animate().scaleX(0.94f).scaleY(0.94f).setDuration(70).start()
                    v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    startSending(ch)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.isPressed = false
                    v.animate().scaleX(1f).scaleY(1f).setDuration(110).start()
                    releaseKey(ch)
                }
            }
            true
        }
        padViews[ch] = b
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = cBg
        window.navigationBarColor = cBg
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode =
                    android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        goFullscreen()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(cBg, Color.parseColor("#151A26"))
            )
            setPadding(dp(36), dp(12), dp(36), dp(16))
        }

        // ---- Barra superior: estado + equipo + conectar ----
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        statusDot = View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(cOff) }
        }
        status = TextView(this).apply {
            text = "Desconectado"
            setTextColor(Color.WHITE)
            textSize = 14f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    val t = s?.toString() ?: ""
                    val connected = t.startsWith("Conectado")
                    val color = when {
                        connected -> cOk
                        t.startsWith("Conectando") -> cWarn
                        else -> cOff
                    }
                    (statusDot.background as GradientDrawable).setColor(color)
                    if (::connectBtn.isInitialized) connectBtn.text = if (connected) "Desconectar" else "Conectar"
                }
            })
        }
        val pill = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(10), dp(18), dp(10))
            background = GradientDrawable().apply {
                cornerRadius = dp(24).toFloat()
                setColor(cSurface)
                setStroke(dp(1), Color.parseColor("#2A3142"))
            }
            addView(statusDot, LinearLayout.LayoutParams(dp(10), dp(10)).apply { rightMargin = dp(10) })
            addView(status, LinearLayout.LayoutParams(0, -2, 1f))
        }
        connectBtn = Button(this).apply {
            text = "Conectar"
            isAllCaps = false
            textSize = 14f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            stateListAnimator = null
            minHeight = 0; minimumHeight = 0
            setPadding(dp(22), dp(10), dp(22), dp(10))
            background = padBackground(cBlue, filled = true, radius = 24)
            setOnClickListener {
                if (output != null) disconnect() else chooseDevice()
            }
        }
        top.addView(pill, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(connectBtn, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(12) })
        root.addView(top, LinearLayout.LayoutParams(-1, -2))

        // ---- Cuerpo: cruceta a la izquierda, GOLPE a la derecha ----
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val grid = GridLayout(this).apply {
            rowCount = 3
            columnCount = 3
        }
        fun dir(label: String, ch: Char, row: Int, col: Int) {
            val b = Button(this).apply {
                text = label
                textSize = 30f
                isAllCaps = false
                includeFontPadding = false
                stateListAnimator = null
                background = padBackground(cBlue, filled = false, radius = 28)
                setTextColor(ColorStateList(
                    arrayOf(intArrayOf(android.R.attr.state_pressed), intArrayOf()),
                    intArrayOf(Color.WHITE, cBlue)
                ))
            }
            attachTouch(b, ch)
            grid.addView(b, GridLayout.LayoutParams(GridLayout.spec(row, 1f), GridLayout.spec(col, 1f)).apply {
                width = 0; height = 0; setMargins(dp(7), dp(7), dp(7), dp(7))
            })
        }
        dir("▲", 'F', 0, 1)
        dir("◀", 'L', 1, 0)
        dir("▶", 'R', 1, 2)
        dir("▼", 'B', 2, 1)
        body.addView(grid, LinearLayout.LayoutParams(0, -1, 1.15f).apply { rightMargin = dp(16) })

        // Botón de golpe (letra 'Z'), a la derecha
        val hit = Button(this).apply {
            text = "●"
            textSize = 40f
            isAllCaps = false
            includeFontPadding = false
            stateListAnimator = null
            background = padBackground(cRed, filled = false, radius = 70)
            setTextColor(ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_pressed), intArrayOf()),
                intArrayOf(Color.WHITE, cRed)
            ))
        }
        attachTouch(hit, 'Z')
        val hitBox = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            addView(hit, LinearLayout.LayoutParams(dp(130), dp(130)))
        }
        body.addView(hitBox, LinearLayout.LayoutParams(0, -1, 0.85f))
        root.addView(body, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(8) })

        setContentView(root)
        requestBtPermission()
    }

    @Suppress("DEPRECATION")
    private fun goFullscreen() {
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let {
                it.hide(android.view.WindowInsets.Type.statusBars() or android.view.WindowInsets.Type.navigationBars())
                it.systemBarsBehavior =
                    android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
            return
        }
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            )
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) goFullscreen()
    }

    private fun requestBtPermission() {
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 1)
    }

    private fun adapter(): BluetoothAdapter? =
        (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter

    private fun chooseDevice() {
        val ad = adapter()
        if (ad == null || !ad.isEnabled) {
            Toast.makeText(this, "Activa el Bluetooth", Toast.LENGTH_SHORT).show()
            return
        }
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) { requestBtPermission(); return }

        val devices: List<BluetoothDevice> = ad.bondedDevices.toList()
        if (devices.isEmpty()) {
            Toast.makeText(this, "Vincula primero el dispositivo en Ajustes > Bluetooth", Toast.LENGTH_LONG).show()
            return
        }
        val names = devices.map { "${it.name ?: "?"}\n${it.address}" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Elige dispositivo")
            .setItems(names) { _, i -> connect(devices[i]) }
            .show()
    }

    private fun disconnect() {
        stopSending()
        padViews.values.forEach { it.isPressed = false }
        status.text = "Desconectado"
        io.execute { close() }
    }

    private fun connect(device: BluetoothDevice) {
        val devName: String = (try { device.name } catch (_: Throwable) { null }) ?: device.address
        status.text = "Conectando a $devName..."
        io.execute {
            close()
            // cancelDiscovery pide permiso BLUETOOTH_SCAN en Android 12+; no es necesario para conectar
            try { adapter()?.cancelDiscovery() } catch (_: Throwable) {}
            var lastError: Throwable? = null

            // Intento 1: método estándar (SPP)
            // Intento 2: método alternativo (canal 1), necesario en varios celulares con HC-05
            for (attempt in 1..2) {
                try {
                    val s: BluetoothSocket = if (attempt == 1) {
                        device.createRfcommSocketToServiceRecord(sppUuid)
                    } else {
                        device.javaClass.getMethod("createRfcommSocket", Int::class.javaPrimitiveType)
                            .invoke(device, 1) as BluetoothSocket
                    }
                    s.connect()
                    socket = s
                    output = s.outputStream
                    ui.post { status.text = "Conectado: $devName" }
                    return@execute
                } catch (e: Throwable) {
                    lastError = e
                    close()
                    try { Thread.sleep(400) } catch (_: InterruptedException) {}
                }
            }
            val msg = lastError?.message ?: lastError?.javaClass?.simpleName ?: "desconocido"
            ui.post { status.text = "Error al conectar ($msg)" }
        }
    }

    private fun startSending(c: Char) {
        // Solo 'Z' (golpear) se combina con otro botón. Las direcciones son exclusivas:
        // la última que se aprieta reemplaza a la anterior.
        if (c != 'Z') {
            val replaced = held.filter { it != 'Z' && it != c }
            held.removeAll(replaced.toSet())
            replaced.forEach { padViews[it]?.apply { isPressed = false; animate().scaleX(1f).scaleY(1f).setDuration(110).start() } }
        }
        if (!held.contains(c)) held.add(c)
        ui.removeCallbacks(repeater)
        ui.post(repeater)
    }

    /** Suelta un botón; si queda otro apretado, sigue enviando ese. */
    private fun releaseKey(c: Char) {
        held.remove(c)
        if (held.isEmpty()) ui.removeCallbacks(repeater)
    }

    private fun stopSending() {
        held.clear()
        ui.removeCallbacks(repeater)
    }

    private fun send(c: Char) {
        io.execute {
            try {
                output?.apply { write(c.code); flush() }
            } catch (e: Exception) {
                close()
                ui.post { status.text = "Conexión perdida" }
            }
        }
    }

    private fun close() {
        try { socket?.close() } catch (_: Exception) {}
        socket = null; output = null
    }

    override fun onDestroy() {
        stopSending()
        close()
        io.shutdown()
        super.onDestroy()
    }
}
